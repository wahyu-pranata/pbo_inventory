/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory_pbo;
import java.sql.*;
import guis.*;

/**
 *
 * @author Wahyu Pranata
 */
public class InventoryPbo {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
       MainGui main = new MainGui();
       main.setVisible(true);
    }
    
}
